/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
/**
 * 
 */
package com.chemistry.enotebook.client.gui.page.batch.table;

import com.chemistry.enotebook.client.controller.MasterController;
import com.chemistry.enotebook.client.gui.page.batch.BatchAttributeComponentUtility;
import com.chemistry.enotebook.client.gui.page.experiment.stoich.StoichDataChangesListener;
import com.chemistry.enotebook.client.gui.page.experiment.table.ParallelCeNUtilObject;
import com.chemistry.enotebook.client.gui.page.table.PCeNProductTableModelConnector;
import com.chemistry.enotebook.client.gui.page.table.PCeNTableView;
import com.chemistry.enotebook.client.gui.tablepreferences.TableColumnInfo;
import com.chemistry.enotebook.client.gui.tablepreferences.TablePreferenceDelegate;
import com.chemistry.enotebook.domain.*;
import com.chemistry.enotebook.experiment.common.MolString;
import com.chemistry.enotebook.experiment.datamodel.batch.InvalidBatchNumberException;
import com.chemistry.enotebook.experiment.datamodel.batch.ProductBatch;
import com.chemistry.enotebook.utils.Decoder;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * 
 * 
 */
public class SingletonCeNProductBatchTableViewControllerUtility implements PCeNProductTableModelConnector {
	private String[] headerNames;
	private ProductBatchModel batchModel;
	private List<ProductBatchModel> batches;
	private List<ParallelCeNUtilObject> listOfBatchesWithMolStrings;
	private boolean structureHidden = false;
	private ProductBatch workingBatch;
	private HashMap<String, String> productProperties = new HashMap<String, String>();
	private NotebookPageModel pageModelPojo ; 
	private List<TableColumnInfo> columnPreferences;

	public SingletonCeNProductBatchTableViewControllerUtility(List<ProductBatchModel> pBatches,
	                                                          NotebookPageModel pageModelPojo) 
	{
		batches = pBatches;
		this.pageModelPojo = pageModelPojo;
		if (pBatches == null)
			throw new IllegalArgumentException("SingletonCeNProductBatchTableViewControllerUtility received NULL argument list");
		//if (batches.size() == 0)
		//	throw new IllegalArgumentException("ParallelCeNProductBatchTableViewControllerUtility received 0 list");
		if (!isStructureHidden()) {
			listOfBatchesWithMolStrings = new ArrayList<ParallelCeNUtilObject>(batches.size());
			// associates batch with a structure
			for (int i = 0; i < batches.size(); i++) {
				batchModel = batches.get(i);
				
				String dspStructures = batchModel.getCompound().getStringSketchAsString();
				
				//System.out.println("dspStructures "+dspStructures);
				ParallelCeNUtilObject abstractBatchWithMolString = new ParallelCeNUtilObject(batchModel, 
				                                                                             new MolString(Decoder.decodeString(dspStructures), i), this,i);
				listOfBatchesWithMolStrings.add(abstractBatchWithMolString);
			}// end for
		}
		if (batches.size() > 0) {
			batchModel = batches.get(0);
			// //System.out.println("The first batch of PRB is : " +
			// batchModel.getCompound().getDspStructure());
			workingBatch = new ProductBatch(batchModel);
			productProperties = workingBatch.getBatchProperties();
		}
		createHeaderNames();
		// col prefs
		columnPreferences = this.setDefaultColumnPrefs();
	}
	
	public void addProductBatchModel(ProductBatchModel productBatchModel) {
		String dspStructures = "";
		if (StringUtils.isNotBlank(productBatchModel.getCompound().getStringSketchAsString()))
		{
			dspStructures = productBatchModel.getCompound().getStringSketchAsString();
			dspStructures = Decoder.decodeString(dspStructures);
		}
		
		ParallelCeNUtilObject abstractBatchWithMolString = new ParallelCeNUtilObject(productBatchModel, new MolString(dspStructures, batches.size()), this,batches.size());
		batches.add(productBatchModel);
		listOfBatchesWithMolStrings.add(abstractBatchWithMolString);
	}
	
	public void removeProductBatchModel(ProductBatchModel productBatchModel){
		int index = batches.indexOf(productBatchModel);
		reArrangeMolString(index);
		if(productBatchModel.isLoadedFromDB())
			productBatchModel.setToDelete(true);
		batches.remove(productBatchModel);
		if (listOfBatchesWithMolStrings != null)
			listOfBatchesWithMolStrings.remove(index);
	}
	
	
	private void reArrangeMolString(int index) {
		for (int i=index; i<listOfBatchesWithMolStrings.size(); i++)
			((ParallelCeNUtilObject)listOfBatchesWithMolStrings.get(i)).getMolString().setIndex(i-1);
	}


	private List<TableColumnInfo> setDefaultColumnPrefs() {
		List<TableColumnInfo> columnPrefs = new ArrayList<TableColumnInfo>();
		for (int i=0; i<headerNames.length; i++) {
			String name = headerNames[i];
			TableColumnInfo colInfo = new TableColumnInfo();
			colInfo.setColumnIndex(i);
			colInfo.setModelIndex(i);
			colInfo.setPreferredWidth(70); // ignore???
			if (name.equals(PCeNTableView.SALT_CODE)
			 || name.equals(PCeNTableView.SALT_EQ)
			 || name.equals(PCeNTableView.TIMES_USED)
			 || name.equals(PCeNTableView.PLATE)
			 || name.equals(PCeNTableView.WELL_POSITION)
			 || name.equals(PCeNTableView.LIMITING)
			 || name.equals(PCeNTableView.PARENT_MW)
			 || name.equals(PCeNTableView.DELIVERED_VOLUME)
			 || name.equals(PCeNTableView.RXN_VOLUME)
			 || name.equals(PCeNTableView.RXN_EQ)
			 || name.equals(PCeNTableView.DEAD_VOLUME)
			 || name.equals(PCeNTableView.DENSITY)
			 || name.equals(PCeNTableView.MOLARITY)
			 || name.equals(PCeNTableView.PURITY)
			 || name.equals(PCeNTableView.EXPTAB_HAZARD_COMMENTS)
			 || name.equals(PCeNTableView.COMMENTS)
			 )
				colInfo.setVisible(false);
			else
				colInfo.setVisible(true);
			columnPrefs.add(colInfo);
		}
		return columnPrefs;
	}


	private void createHeaderNames() {
		int index = 0;
		if (!structureHidden) {
			headerNames = new String[productProperties.size() + 8];
			headerNames[index] = PCeNTableView.STRUCTURE;
			index++;
		}
		else 
			headerNames = new String[productProperties.size() + 7];
			
		headerNames[index] = PCeNTableView.NBK_BATCH_NUM;
		index++;
		headerNames[index] = PCeNTableView.AMT_MADE;
		index++;		
		headerNames[index] = PCeNTableView.THEORETICAL_WEIGHT;
		index++;
		headerNames[index] = PCeNTableView.THEORETICAL_MMOLES;
		index++;
		headerNames[index] = PCeNTableView.PERCENT_YIELD;
		index++;
		headerNames[index] = PCeNTableView.CONVERSATIONAL_BATCH;
		index++;		
		headerNames[index] = PCeNTableView.BATCH_COMMENTS;
		index++;
		
		for (Iterator<String> itr = productProperties.keySet().iterator(); itr.hasNext();) {
			headerNames[index] = (String) itr.next();
			index++;
		}
	}

	public String[] getHeaderNames() {
		return headerNames;
	}

	public Object getValue(int rowIndex, int colIndex) {
		ProductBatchModel batch = null;
		if (isStructureHidden() == false) 
			batch = (ProductBatchModel) ((ParallelCeNUtilObject) listOfBatchesWithMolStrings.get(rowIndex)).getBatch();
		else 
			batch = batches.get(rowIndex);
			
		if (headerNames[colIndex].equals(PCeNTableView.STRUCTURE)) {
			String molString = ((ProductBatchModel) ((ParallelCeNUtilObject) listOfBatchesWithMolStrings
					.get(rowIndex)).getBatch()).getCompound()
					.getStringSketchAsString();
			((ParallelCeNUtilObject) listOfBatchesWithMolStrings
					.get(rowIndex)).getMolString().setMolString(molString);
			return ((ParallelCeNUtilObject) listOfBatchesWithMolStrings
					.get(rowIndex)).getMolString();
		} else if (headerNames[colIndex].equals(PCeNTableView.NBK_BATCH_NUM)) {
			return BatchAttributeComponentUtility.getNotebookBatchNumber(batch);
		} else if (headerNames[colIndex].equals(PCeNTableView.AMT_MADE)) {
			return batch.getTotalWeight();
		} else if (headerNames[colIndex].equals(PCeNTableView.THEORETICAL_WEIGHT)) {
			return batch.getTheoreticalWeightAmount();
		} else if (headerNames[colIndex].equals(PCeNTableView.THEORETICAL_MMOLES)) {
			return batch.getTheoreticalMoleAmount();
		} else if (headerNames[colIndex].equals(PCeNTableView.PERCENT_YIELD)) {
			return batch.getTheoreticalYieldPercentAmount();
		} else if (headerNames[colIndex].equals(PCeNTableView.CONVERSATIONAL_BATCH)) {
			return batch.getRegInfo().getConversationalBatchNumber();
		}
		else if (headerNames[colIndex].equals(PCeNTableView.BATCH_COMMENTS)) {
			return ((batch.getComments().equals("")) ? "" : ""+batch.getComments());
		}
		return batch.getBatchProperties().get(headerNames[colIndex]);
	}

	public boolean isCellEditable(int rowIndex, int colIndex) {
		if (headerNames[colIndex].equalsIgnoreCase(PCeNTableView.BATCH_COMMENTS)
			||headerNames[colIndex].equalsIgnoreCase(PCeNTableView.NBK_BATCH_NUM))
			return true;
		else
			return false;
	}

	public void setValue(Object val, int rowIndex, int colIndex) {
		String value = (String) val;
		ProductBatchModel pbatch = null;
		boolean isUpdated = false;
		pbatch = (ProductBatchModel) ((ParallelCeNUtilObject) listOfBatchesWithMolStrings.get(rowIndex)).getBatch();
		if (headerNames[colIndex].equals(PCeNTableView.BATCH_COMMENTS)) {
			pbatch.setComments(value);
			isUpdated = true;
		} else if (headerNames[colIndex].equals(PCeNTableView.NBK_BATCH_NUM)) {
			if (value.length() == 0)
				return;
			try {
				pbatch.getBatchNumber().setBatchNumber(value);
				isUpdated = true;
			} catch (InvalidBatchNumberException e) {
				return;
			}
		} 
		if (isUpdated)
		{
			pageModelPojo.setModelChanged(true);
			enableSaveButton();
		}
	}

	private void enableSaveButton() {
		MasterController.getGUIComponent().enableSaveButtons();
	}
	public boolean isStructureHidden() {
		return structureHidden;
	}

	/**
	 * @return the abstractBatches
	 */
	public List getAbstractBatches() {
		return batches;
	}

	/**
	 * @param abstractBatches
	 *            the abstractBatches to set
	 */
	public void setAbstractBatches(List abstractBatches) {
		this.batches = abstractBatches;
	}

	/**
	 * @return the listOfBatchesWithMolStrings
	 */
	public List<ParallelCeNUtilObject> getListOfBatchesWithMolStrings() {
		return listOfBatchesWithMolStrings;
	}

	/**
	 * @param listOfBatchesWithMolStrings
	 *            the listOfBatchesWithMolStrings to set
	 */
	public void setListOfBatchesWithMolStrings(List<ParallelCeNUtilObject> listOfBatchesWithMolStrings) {
		this.listOfBatchesWithMolStrings = listOfBatchesWithMolStrings;
	}

	public String getTableHeaderTooltip(String headerName) {
		return null;
	}
	public int getRowCount() {
		if (!isStructureHidden())
			return getListOfBatchesWithMolStrings().size();
		else {
			if (getAbstractBatches() == null)
				return 0;
			return getAbstractBatches().size();
		}
		
	}
	public boolean isSortable(int col) {
		return true;
	}
//	This method is not applicable here
	public List getStoicElementListInTransactionOrder()
	{
		return null;
	}
	
	public void updateColumn(String cloumnname, Object newValue)
	{
		
	}
	public void setSelectValue(int selectedRow) {
		// TODO Auto-generated method stub
		
	}



	public void sortBatches(int colIndex, boolean ascending) {
		// TODO Auto-generated method stub
		
	}



	public boolean isMoreDeletableRows(ReactionStepModel model) {
		if (!isStructureHidden()) 
			return ((listOfBatchesWithMolStrings.size() > 0) ? true : false);
		else
			return ((batches.size() > 0) ? true : false);
	}

	public StoicModelInterface getBatchModel(int selectedRowIndex) {
		return batches.get(selectedRowIndex);
	}

	public StoicModelInterface getProductBatchModel(int selectedRowIndex) {
		return batches.get(selectedRowIndex);
}


	public boolean isColumnEditable(String columnName) {
		if (columnName.equalsIgnoreCase(PCeNTableView.BATCH_COMMENTS)
				||columnName.equalsIgnoreCase(PCeNTableView.NBK_BATCH_NUM))
				return true;
			else
				return false;
	}


	public void addProductBatchModel(ProductBatchModel batch,
	                                 ProductPlate pseudoPlate) {
		//Not applicable to Singleton exps.
	}

	public void updateProductBatchModel(ProductBatchModel batch) {
		//Not applicable to Singleton exps.		
	}



	public void addStoichDataChangesListener(
			StoichDataChangesListener stoichDataChangesListener) {
		// TODO Auto-generated method stub
		
	}

	public TableColumnInfo getColumnInfoFromModelIndex(int modelIndex) {
		if (this.columnPreferences.size() > modelIndex)
			return (TableColumnInfo) this.columnPreferences.get(modelIndex);
		else
			return null;
	}

	public TablePreferenceDelegate getTablePreferenceDelegate() {
		// TODO Auto-generated method stub
		return null;
	}

	public NotebookPageModel getPageModel() {
		return pageModelPojo;
	}
	
}
