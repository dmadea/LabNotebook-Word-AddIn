/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
/**
 * 
 */
package com.chemistry.enotebook.client.gui.page.conception;

import com.chemistry.enotebook.client.controller.MasterController;
import com.chemistry.enotebook.client.gui.common.errorhandler.CeNErrorHandler;
import com.chemistry.enotebook.client.gui.page.batch.BatchAttributeComponentUtility;
import com.chemistry.enotebook.client.gui.page.experiment.stoich.StoichDataChangesListener;
import com.chemistry.enotebook.client.gui.page.experiment.table.ParallelCeNUtilObject;
import com.chemistry.enotebook.client.gui.page.table.PCeNProductTableModelConnector;
import com.chemistry.enotebook.client.gui.page.table.PCeNTableModelConnectorCommon;
import com.chemistry.enotebook.client.gui.page.table.PCeNTableView;
import com.chemistry.enotebook.client.gui.tablepreferences.TableColumnInfo;
import com.chemistry.enotebook.client.gui.tablepreferences.TablePreferenceDelegate;
import com.chemistry.enotebook.domain.*;
import com.chemistry.enotebook.experiment.common.MolString;
import com.chemistry.enotebook.experiment.datamodel.batch.InvalidBatchNumberException;
import com.chemistry.enotebook.experiment.datamodel.user.UserPreferenceException;
import com.chemistry.enotebook.utils.Decoder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.swing.*;
import java.util.*;

/**
 * 
 * 
 */
public class ConceptionCeNProductBatchTableViewControllerUtility implements PCeNProductTableModelConnector {
	public static final Log log = LogFactory.getLog(ConceptionCeNProductBatchTableViewControllerUtility.class);

	private String[] headerNames;
	private ProductBatchModel batchModel;
	private List<ProductBatchModel> batches;
	private List<ParallelCeNUtilObject> listOfBatchesWithMolStrings;
	// private boolean structureHidden = false;
	private NotebookPageModel pageModel;

	// Preferences
	private List columnPreferences;
	private TablePreferenceDelegate preferenceDelegate;
	private static final String tableName = "Conception_Preferred_Compounds_Summary_Table";
	private static final String[] columnNames = { PCeNTableView.STRUCTURE, 
												  PCeNTableView.NBK_BATCH_NUM, 
												  PCeNTableView.SELECT_OPTION,
												  PCeNTableView.VIRTUAL_COMP_NUM, 
												  PCeNTableView.MOL_WEIGHT,
												  PCeNTableView.MOL_FORMULA, 
												  PCeNTableView.STEREOISOMER,
												  PCeNTableView.STRUCTURE_COMMENTS, 
												  PCeNTableView.COMMENTS };

	public ConceptionCeNProductBatchTableViewControllerUtility(List<ProductBatchModel> pBatches, NotebookPageModel pageModelPojo) {
		this.pageModel = pageModelPojo;
		batches = pBatches;
		if (batches == null)
			throw new IllegalArgumentException("ParallelCeNProductBatchTableViewControllerUtility received NULL argument list");
		if (!isStructureHidden()) {
			listOfBatchesWithMolStrings = new ArrayList<ParallelCeNUtilObject>(pBatches.size());
			// associates batch with a structure
			for (int i = 0; i < batches.size(); i++) {
				batchModel = batches.get(i);
				String dspStructures = batchModel.getCompound().getStringSketchAsString();

				// System.out.println("dspStructures "+dspStructures);
				ParallelCeNUtilObject abstractBatchWithMolString = new ParallelCeNUtilObject(batchModel, new MolString(Decoder
						.decodeString(dspStructures), i), this, i);
				listOfBatchesWithMolStrings.add(abstractBatchWithMolString);
			}
		}
		if (batches.size() > 0) {
			batchModel = (ProductBatchModel) batches.get(0);
//			workingBatch = new ProductBatch(batchModel);
			// productProperties = workingBatch.getBatchProperties();
		}
		// col prefs
		try {
			preferenceDelegate = new TablePreferenceDelegate(tableName, this.pageModel, columnNames);
			columnPreferences = preferenceDelegate.getColumnPreferences();
			// if (columnPreferences == null || columnPreferences.size() == 0) {
			// 		columnPreferences = this.setDefaultColumnPrefs();
			// 		//preferenceDelegate.setDefaultTablePropertiesFromModel(this.createDefaultColumnInfoXml());
			// }
		} catch (UserPreferenceException e) {
			log.error("Unable to set table preferences : " + e.getMessage());
			CeNErrorHandler.getInstance().logExceptionMsg(MasterController.getGUIComponent(), "Unable to set table preferences.", e);
		}
		createHeaderNames();
	}

	public void removeProductBatchModel(ProductBatchModel productBatchModel) {
		int index = batches.indexOf(productBatchModel);
		reArrangeMolString(index);
		if (productBatchModel.isLoadedFromDB())
			productBatchModel.setToDelete(true);
		batches.remove(productBatchModel);
		if (listOfBatchesWithMolStrings != null)
			listOfBatchesWithMolStrings.remove(index);
	}

	private void reArrangeMolString(int index) {
		for (int i = index; i < listOfBatchesWithMolStrings.size(); i++)
			((ParallelCeNUtilObject) listOfBatchesWithMolStrings.get(i)).getMolString().setIndex(i - 1);
	}

	private void createHeaderNames() {
//		headerNames = new String[this.columnPreferences.size()];
//		for (Iterator it = this.columnPreferences.iterator(); it.hasNext();) {
//			TableColumnInfo colinfo = (TableColumnInfo) it.next();
//			headerNames[colinfo.getModelIndex()] = colinfo.getLabel();
//		}
		headerNames = columnNames;
	}

	public String[] getHeaderNames() {
		return headerNames;
	}

	public Object getValue(int rowIndex, int colIndex) {
		ProductBatchModel batch = null;
		if (!isStructureHidden()) {
			batch = (ProductBatchModel)((ParallelCeNUtilObject) listOfBatchesWithMolStrings.get(rowIndex)).getBatch();
			if (headerNames[colIndex].equals(PCeNTableView.STRUCTURE)) {
				String molString = batch.getCompound().getStringSketchAsString();
				MolString rxn = ((ParallelCeNUtilObject) listOfBatchesWithMolStrings.get(rowIndex)).getMolString();

				if (molString != null) {
					int index = molString.indexOf("M  END");
					if (index == -1) {
						molString = Decoder.decodeString(molString);
					}
				}
				rxn.setMolString(molString);
				log.debug(molString);
				return rxn;
				// return ((ProductBatchModel)((ParallelCeNUtilObject)
				// listOfBatchesWithMolStrings.get(rowIndex)).getBatch()).getCompound().getNativeSketch();
			} else if (headerNames[colIndex].equals(PCeNTableView.SELECT_OPTION)) {
				return new Boolean(batch.isSelected());
			} else if (headerNames[colIndex].equals(PCeNTableView.NBK_BATCH_NUM)) {
				return BatchAttributeComponentUtility.getNotebookBatchNumber(batch);
			} else if (headerNames[colIndex].equals(PCeNTableView.MOL_WEIGHT)) {
				return batch.getMolecularWeightAmount();
			} else if (headerNames[colIndex].equals(PCeNTableView.MOL_FORMULA)) {
				return batch.getCompound().getMolFormula();
			} else if (headerNames[colIndex].equals(PCeNTableView.COMMENTS)) {
				return batch.getComments();
			} else if (headerNames[colIndex].equals(PCeNTableView.VIRTUAL_COMP_NUM)) {
				return batch.getCompound().getVirtualCompoundId();
			} else if (headerNames[colIndex].equals(PCeNTableView.STEREOISOMER)) {
				return batch;
			} else if (headerNames[colIndex].equals(PCeNTableView.STRUCTURE_COMMENTS)) {
				return batch.getCompound().getStructureComments();
			}
		}
		return "";
	}

	public boolean isCellEditable(int rowIndex, int colIndex) {
		if (headerNames[colIndex].equalsIgnoreCase(PCeNTableView.NBK_BATCH_NUM)
				|| headerNames[colIndex].equalsIgnoreCase(PCeNTableView.COMMENTS)
				|| headerNames[colIndex].equalsIgnoreCase(PCeNTableView.STRUCTURE_COMMENTS)
				|| headerNames[colIndex].equalsIgnoreCase(PCeNTableView.STEREOISOMER)
				|| headerNames[colIndex].equalsIgnoreCase(PCeNTableView.SELECT_OPTION))
			return true;
		else
			return false;
	}

	public void setValue(Object value, int rowIndex, int colIndex) {
		BatchModel batch = ((ParallelCeNUtilObject) listOfBatchesWithMolStrings.get(rowIndex)).getBatch();
		if (headerNames[colIndex].equals(PCeNTableView.NBK_BATCH_NUM)) {
			try {
				if (BatchAttributeComponentUtility.setNotebookBatchNumber(batch, (String) value, pageModel))
					enableSaveButton();
			} catch (InvalidBatchNumberException e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Data Exception", JOptionPane.ERROR_MESSAGE);
			}
		} else if (headerNames[colIndex].equals(PCeNTableView.COMMENTS)) {
			if (value instanceof String) {
				batch.setComments((String) value);
				enableSaveButton();
			}
		} else if (headerNames[colIndex].equals(PCeNTableView.STRUCTURE_COMMENTS)) {
			if (value instanceof String) {
				batch.getCompound().setStructureComments((String) value);
				enableSaveButton();
			}
		} else if (headerNames[colIndex].equals(PCeNTableView.STEREOISOMER)) {
			if (value instanceof String) {
				batch.getCompound().setStereoisomerCode((String) value);
				enableSaveButton();
			}
		}
	}

	private void enableSaveButton() {
		pageModel.setModelChanged(true);
		MasterController.getGUIComponent().enableSaveButtons();
	}

	/**
	 * @return the abstractBatches
	 */
	public List getAbstractBatches() {
		return batches;
	}

	/**
	 * @param abstractBatches
	 *            the abstractBatches to set
	 */
	public void setAbstractBatches(List abstractBatches) {
		this.batches = abstractBatches;
	}

	/**
	 * @return the listOfBatchesWithMolStrings
	 */
	public List getListOfBatchesWithMolStrings() {
		return listOfBatchesWithMolStrings;
	}

	/**
	 * @param listOfBatchesWithMolStrings
	 *            the listOfBatchesWithMolStrings to set
	 */
	public void setListOfBatchesWithMolStrings(List listOfBatchesWithMolStrings) {
		this.listOfBatchesWithMolStrings = listOfBatchesWithMolStrings;
	}

	public String getTableHeaderTooltip(String headerName) {
		return null;
	}

	public int getRowCount() {
		if (!isStructureHidden())
			return getListOfBatchesWithMolStrings().size();
		else {
			if (getAbstractBatches() == null)
				return 0;
			return getAbstractBatches().size();
		}
	}

	public boolean isSortable(int col) {
		return true;
	}

	public List<StoicModelInterface> getStoicElementListInTransactionOrder() {
		List<StoicModelInterface> stoichList = new ArrayList<StoicModelInterface>();
		stoichList.addAll(batches);
		return stoichList;
	}

	public void updateColumn(String columnName, Object newValue) {
		if (new PCeNTableModelConnectorCommon(pageModel).updateColumn(batches, columnName, newValue))
			enableSaveButton();
	}

	public void setSelectValue(int selectedRow) {
		// TODO Auto-generated method stub
	}

	public void sortBatches(int colIndex, boolean ascending) {
		// TODO Auto-generated method stub
	}

	public boolean isMoreDeletableRows(ReactionStepModel model) {
		if (!isStructureHidden())
			return ((listOfBatchesWithMolStrings.size() > 0) ? true : false);
		else
			return ((batches.size() > 0) ? true : false);
	}

	public StoicModelInterface getProductBatchModel(int selectedRowIndex) {
		return batches.get(selectedRowIndex);
	}

	public StoicModelInterface getBatchModel(int selectedRowIndex) {
		return batches.get(selectedRowIndex);
	}

	public boolean isColumnEditable(String columnName) {
		if (columnName.equalsIgnoreCase(PCeNTableView.STRUCTURE))
			return false;
		else
			return true;
	}

    public void removeAllBatches() {
        batches.clear();
        listOfBatchesWithMolStrings.clear();
    }

	public void addProductBatchModel(ProductBatchModel productBatchModel) {
		// String dspStructures = "";

		// System.out.println("dspStructures "+dspStructures);
		ParallelCeNUtilObject abstractBatchWithMolString = new ParallelCeNUtilObject(productBatchModel, 
						new MolString("", batches.size()), this, batches.size());
		// ParallelCeNUtilObject abstractBatchWithMolString = new ParallelCeNUtilObject(productBatchModel, new
		// MolString(productBatchModel.getCompound().getNativeSketch().toString(), batches.size()), this,batches.size());
		batches.add(productBatchModel);
		listOfBatchesWithMolStrings.add(abstractBatchWithMolString);
	}

	public void addProductBatchModel(ProductBatchModel batch, ProductPlate pseudoPlate) {
		// Not applicable for Conception
	}

	public void updateProductBatchModel(ProductBatchModel batch) {
		// Not applicable for Conception
	}

	public void addStoichDataChangesListener(StoichDataChangesListener stoichDataChangesListener) {
		// TODO Auto-generated method stub
	}

	public TableColumnInfo getColumnInfoFromModelIndex(int modelIndex) {
		if (this.columnPreferences.size() > modelIndex)
			return (TableColumnInfo) this.columnPreferences.get(modelIndex);
		else
			return null;
	}

	public TablePreferenceDelegate getTablePreferenceDelegate() {
		return this.preferenceDelegate;
	}

	public boolean isStructureHidden() {
		return false;
	}

	public Map getColumnInfoMappedByLabel() {
		HashMap map = new HashMap();
		for (Iterator it = this.columnPreferences.iterator(); it.hasNext();) {
			TableColumnInfo colinfo = (TableColumnInfo) it.next();
			if (colinfo.getLabel() != null && colinfo.getLabel().length() > 0)
				map.put(colinfo.getLabel(), colinfo);
		}
		return map;
	}

	public NotebookPageModel getPageModel() {
		return pageModel;
	}

}
