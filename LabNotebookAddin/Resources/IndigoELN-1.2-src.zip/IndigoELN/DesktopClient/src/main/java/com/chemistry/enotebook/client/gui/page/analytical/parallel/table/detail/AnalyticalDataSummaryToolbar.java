/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
package com.chemistry.enotebook.client.gui.page.analytical.parallel.table.detail;

import com.chemistry.enotebook.client.controller.MasterController;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.PAnalyticalUtility;
import com.chemistry.enotebook.domain.NotebookPageModel;
import com.chemistry.enotebook.utils.CeNJobProgressHandler;
import com.chemistry.enotebook.utils.SwingWorker;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// vb 7/17
public class AnalyticalDataSummaryToolbar extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7551399674522130927L;

	private static final Log log = LogFactory.getLog(AnalyticalDataSummaryToolbar.class);
	
	private JButton jButtonQuickLinkAll;
	private JButton jButtonAdvancedLink;
	private NotebookPageModel pageModel;
	private PAnalyticalUtility analyticalUtil;
	
	public AnalyticalDataSummaryToolbar(NotebookPageModel pageModel, AnalyticalChangeListener analyticalChangeListener) {
		this.pageModel = pageModel;
		analyticalUtil = new PAnalyticalUtility(pageModel, analyticalChangeListener);
		initGui();
	}
	
	private void initGui() {
		jButtonQuickLinkAll = new JButton("Quick Link All");
		jButtonQuickLinkAll.setEnabled(this.pageModel.isEditable());
		jButtonQuickLinkAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jButtonQuickLinkAllReleased(e);
			}
		});
		jButtonAdvancedLink = new JButton("Advanced Link");
		jButtonAdvancedLink.setEnabled(this.pageModel.isEditable());
		jButtonAdvancedLink.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAdvanceLinkDialog(e);
			}
		});
		refresh();
	}
	
	public JPanel getPanel() {
		FormLayout layout = new FormLayout("right:300dlu, 10dlu, right:pref, right:pref", "pref");
		PanelBuilder builder = new PanelBuilder(layout);
		CellConstraints cc = new CellConstraints();
		//JLabel numCompoundsLabel = new JLabel("Number of Compounds");
		//numCompoundsLabel.setFont(new java.awt.Font("Arial", Font.BOLD, 12));
		//builder.add(numCompoundsLabel, cc.xy  (1,   1)); 
		builder.add(this.jButtonQuickLinkAll, cc.xy(3, 1));
		builder.add(this.jButtonAdvancedLink, cc.xy(4, 1));
		return builder.getPanel();
	}
	
	private void showAdvanceLinkDialog(ActionEvent e) {
//		jTableAnalyticalViewer.setAnalyticalDataModel(analyticalModel);
		try {
			PAnalyticalAdvancedLinkDialog aJDialog = new PAnalyticalAdvancedLinkDialog(MasterController.getGUIComponent());
			aJDialog.setAnalyticalModel(analyticalUtil);
//			aJDialog.setTableViewer(jTableAnalyticalViewer);
			aJDialog.setVisible(true);
		} catch (Exception error) {
			log.error("Failed to show Advanced Link Dialog: " + error.toString(), error);
		}
	}
	
	/**
	 * 
	 * @param evt
	 */
	protected void jButtonQuickLinkAllReleased(ActionEvent evt) {
		final String progressStatus = "Performing Quick Link All ...";
		CeNJobProgressHandler.getInstance().addItem(progressStatus);
		SwingWorker quikLinkAll = new SwingWorker() {
			boolean success;

			public Object construct() {
				setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				ArrayList sites = new ArrayList();
				sites.add(pageModel.getSiteCode());
				success = analyticalUtil.performQuickLinkAll(pageModel.getNotebookRefWithoutVersion(), sites);
				return null;
			}

			public void finished() {
				CeNJobProgressHandler.getInstance().removeItem(progressStatus);
				setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				if (success)
					//jTableAnalyticalViewer.reload();
					System.out.println("This reload of new model should be checked");
				else
					JOptionPane.showMessageDialog(MasterController.getGuiController().getGUIComponent(),
							"Unable to find any Quick Link results", "Quick Link", JOptionPane.INFORMATION_MESSAGE);
				;
			}
		};
		quikLinkAll.start();
	}

	public void refresh() {
		boolean enable = pageModel.isEditable();
		jButtonQuickLinkAll.setEnabled(enable);
		jButtonAdvancedLink.setEnabled(enable);
	}

}