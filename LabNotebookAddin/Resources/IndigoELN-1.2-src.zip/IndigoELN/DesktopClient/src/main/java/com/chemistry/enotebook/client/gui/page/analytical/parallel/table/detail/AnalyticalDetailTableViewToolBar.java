/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
package com.chemistry.enotebook.client.gui.page.analytical.parallel.table.detail;

import com.chemistry.enotebook.utils.DefaultPreferences;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnalyticalDetailTableViewToolBar extends JPanel {
	
	private static final long serialVersionUID = -1190760584570009599L;
	
	private AnalyticalDetailTableView comp;
	private boolean on = true;
	private boolean includeStructure = true;
	private JCheckBox structureSwitch;
	private JSlider rowHeightSlider;

	public AnalyticalDetailTableViewToolBar() {
	}

	public AnalyticalDetailTableViewToolBar(AnalyticalDetailTableView comp) {
		this.comp = comp;
		this.setLayout(new BorderLayout());
		this.structureSwitch = new JCheckBox("Show/Hide Structures");
		this.comp.setToolBar(this);
		this.init();
	}

	public AnalyticalDetailTableViewToolBar(AnalyticalDetailTableView comp, JPanel otherElements) {
		this(comp);
		this.add(otherElements, BorderLayout.LINE_END);
	}

	private void init() {
		if (includeStructure) {
			structureSwitch.setSelected(on);
			structureSwitch.setText("Hide Structures");
			
			structureSwitch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					includeStructure = structureSwitch.isSelected();
					comp.setSelectedAreas(null);  
					comp.showStructureColumn(includeStructure);
					comp.refresh();
					comp.sizeColumnsToFit(-1);
				}
			});
			
			if (structureSwitch.isSelected()) {
				structureSwitch.doClick();
			}				
		}

		rowHeightSlider = new JSlider(JSlider.HORIZONTAL, 1, 400, comp.getRowHeight());
		rowHeightSlider.addChangeListener(comp);

		this.setLayout(new FlowLayout(FlowLayout.LEFT));
		this.add(rowHeightSlider);
		this.add(structureSwitch);
		this.add(new JPanel());
	}
	
	public boolean isIncludeStructure() {
		return includeStructure;
	}

	public void setIncludeStructure(boolean includeStructure) {
		this.includeStructure = includeStructure;
	}

	public void changeStructureCheckBox(boolean show) {
		structureSwitch.setSelected(show);
		if (show) {
			structureSwitch.setText("Hide Structures");
			comp.setRowHeight(DefaultPreferences.TALL_ROW_HEIGHT); 
		} else {
			structureSwitch.setText("Show Structures");
			comp.setRowHeight(DefaultPreferences.SHORT_ROW_HEIGHT); 
		}
	}
}
