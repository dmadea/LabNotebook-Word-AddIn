/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
package com.chemistry.enotebook.client.gui.page.analytical.parallel;

import com.chemistry.enotebook.client.gui.common.collapsiblepane.CollapsiblePane;
import com.chemistry.enotebook.client.gui.page.ParallelNotebookPageGUI;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.batch.AnalyticalBatchEditPanel;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.batch.AnalyticalPlateBatchViewPanel;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.table.detail.AnalyticalChangeListener;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.table.detail.AnalyticalDetailTableModel;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.table.detail.AnalyticalDetailTableView;
import com.chemistry.enotebook.client.gui.page.analytical.parallel.table.detail.AnalyticalDetailTableViewToolBar;
import com.chemistry.enotebook.client.gui.page.batch.BatchSelectionEvent;
import com.chemistry.enotebook.client.gui.page.batch.BatchSelectionListener;
import com.chemistry.enotebook.client.gui.page.batch.CompoundCreationEvent;
import com.chemistry.enotebook.client.gui.page.batch.events.*;
import com.chemistry.enotebook.client.gui.page.batch.table.ProductTablePopupMenuManager;
import com.chemistry.enotebook.client.gui.page.experiment.plate.CeNProductPlateBuilder;
import com.chemistry.enotebook.domain.*;
import com.chemistry.enotebook.utils.NbkBatchNumberComparator;
import com.chemistry.enotebook.utils.ProductBatchFilter;
import com.virtuan.plateVisualizer.StaticPlateRenderer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.*;
import java.util.List;

public class PCeNAnalytical_BatchDetailsViewContainer implements PlatesCreatedEventListener, ItemListener,
		CompoundCreatedEventListener, AnalyticalChangeListener, ActionListener {

	public static final Log log = LogFactory.getLog(PCeNAnalytical_BatchDetailsViewContainer.class);

	public static final String TABLES_VIEW = "Tables";
	public static final String PLATES_VIEW = "Plates";

	private CollapsiblePane viewBatch_Pane;

	// private ProductBatchRackViewPanel mProductBatchRackViewPanel;
	// ///////private BatchSelectionListener mBatchSelectionListener = null;
	private JTabbedPane productTableTabbedPane;
	// private JTabbedPane plateTableViewTab;
	private JTabbedPane plateRackViewTab;
	private NotebookPageModel pageModel;
	// private JPanel productTableViewPanel = new JPanel();
	private JPanel stepTabTableViewPanel = new JPanel();
	private List tableList = new ArrayList(); // keep a list of the tables so we can unset selected row when a we switch to a
												// different table

	private JButton reformaPlatesBtn = new JButton("Reformat Plates");
	private JButton applyAnalyticalBtn = new JButton("Apply Analytical(RPT)");
	private JButton colorLegendBtn = new JButton("Color Legend");
	private JButton exportExcelBtn = new JButton("Export to Excel");

	private boolean isLoading = true;

	// public static final String RACK_VIEW = "Plates";
	// public static final String PRODUCT_TABLE_VIEW = "Tables - Separate Products";
	// public static final String PLATE_TABLE_VIEW = "Tables - Separate Plates";
	// public static final String[] VIEWOPTIONS = { PRODUCT_TABLE_VIEW, PLATE_TABLE_VIEW, RACK_VIEW };

	// private JComboBox viewOptionsCombo = new JComboBox(VIEWOPTIONS);

	private Hashtable productViews = new Hashtable();
	private Hashtable plateViews = new Hashtable();
	// private Hashtable plateTablePaneViews = new Hashtable();
	//private ArrayList nonPlatedBatches = new ArrayList();
	private ProductBatchFilter productBatchFilter = null;
	private ArrayList selectedPlates = new ArrayList();
	// private PCeNAnalyticalBatchInfoTableView nonPlatedTableView;
	// private PCeNAnalyticalBatchInfoTableView lastStepProductTableView; // need this for adding compounds
	private AnalyticalDetailTableView nonPlatedTableView;
	private AnalyticalDetailTableView lastStepProductTableView; // need this for adding compounds
	private ProductTablePopupMenuManager parallelProductTablePopupMenuManagerForPlateTable = new ProductTablePopupMenuManager();
	private ProductTablePopupMenuManager parallelProductTablePopupMenuManagerForProductTable = new ProductTablePopupMenuManager();
	private ReactionStepModel lastStep = null;
	// private BatchType userAddedBatchType = null;
	private PAnalyticalSampleRefContainer sampleRefContainer = null;
	private BatchSelectionListener[] batchSelectionListeners;

	private CeNProductPlateBuilder mCeNProductPlateBuilder = new CeNProductPlateBuilder(); // vb 7/18

	private JRadioButton tablesRadioButton = null;
	private JRadioButton platesRadioButton = null;

	private String selectedView = TABLES_VIEW;

	public PCeNAnalytical_BatchDetailsViewContainer(NotebookPageModel pageModel, PAnalyticalSampleRefContainer sampleRefContainer) {

		// public PlateViewerGUIRenderer(NotebookPageModel pageModel ) {
		this.pageModel = pageModel;
		this.sampleRefContainer = sampleRefContainer;
		this.productBatchFilter = new ProductBatchFilter(pageModel);
		createCollapsiblePane();
		// plateTableViewTab = new JTabbedPane(JTabbedPane.TOP);
		// plateTableViewTab.addChangeListener(new ChangeListener() {
		// public void stateChanged(ChangeEvent e) {
		// refreshTables();
		// }
		// });
		plateRackViewTab = new JTabbedPane(JTabbedPane.TOP);
		plateRackViewTab.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				refreshTables();
			}
		});
		productTableTabbedPane = new JTabbedPane(JTabbedPane.TOP);
		productTableTabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				refreshTables();
			}
		});

		// init combo box and register an itemListener
		// viewOptionsCombo.setPreferredSize(new Dimension(150, 20));
		// viewOptionsCombo.addItemListener(this);
		viewBatch_Pane.getContentPane().add(createToolBarElements(), BorderLayout.NORTH);
		viewBatch_Pane.getContentPane().add(createViewOptionsPanel(), BorderLayout.NORTH);

		// create stepWise tab and add stepWiseProductBatchTableView
		addPlatesToTabs(pageModel.getAllProductPlatesAndRegPlates());
		if(this.pageModel.isParallelExperiment())
		{
		//createNonPlatedBatchesViewTab();
		}
		addProductsToTabs(pageModel);
		updateProducts();
		// viewOptionsCombo.setSelectedIndex(0);
		int noOfSteps = pageModel.getReactionSteps().size();
		lastStep = pageModel.getReactionStep(noOfSteps - 1);
		// try {
		// userAddedBatchType = BatchTypeFactory.getBatchType(CeNConstants.BATCH_TYPE_ACTUAL);
		// } catch (InvalidBatchTypeException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// } // vb 12/6
		isLoading = false;
	}

	private JPanel createViewOptionsPanel() {
		JPanel panel = new JPanel(new BorderLayout(6, 6));
		JPanel viewOptionsPanel = new JPanel(new GridLayout(1, 2, 6, 6));
		if(this.pageModel.isParallelExperiment()){
		tablesRadioButton = new JRadioButton(TABLES_VIEW);
		platesRadioButton = new JRadioButton(PLATES_VIEW);
		ButtonGroup group = new ButtonGroup();
		group.add(tablesRadioButton);
		group.add(platesRadioButton);
		viewOptionsPanel.add(tablesRadioButton);
		viewOptionsPanel.add(platesRadioButton);
		viewOptionsPanel.setBorder(new EmptyBorder(6, 6, 6, 6));
		panel.add(viewOptionsPanel, BorderLayout.EAST);
		tablesRadioButton.setSelected(true);
		tablesRadioButton.addActionListener(this);
		platesRadioButton.addActionListener(this);
	    }
		return panel;
	}

	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if (command.equals(TABLES_VIEW) || command.equals(PLATES_VIEW)) {
			selectedView = command;
			switchView(selectedView);
		}
	}

	private void updateProducts() {
		productTableTabbedPane.removeAll();
		for (Iterator it = this.productViews.keySet().iterator(); it.hasNext();) {
			String key = (String) it.next();
			this.productTableTabbedPane.add(key, (JPanel) this.productViews.get(key));
		}
		switchView(selectedView);
	}

	// private void updateSelectedPlatesProducts(List selectProductPlates) {
	// stepTabTableViewPanel.removeAll();
	// plateRackViewTab.removeAll();
	// plateTableViewTab.removeAll();
	// updateProducts();
	// if (selectProductPlates.size() > 0) {// there are some plates
	// for (int i = 0; i < selectProductPlates.size(); i++) {
	// ProductPlate mProductPlate = (ProductPlate)selectProductPlates.get(i);
	// if (!(mProductPlate instanceof PseudoProductPlate)) {
	// if (mProductPlate.getPlateBarCode() == null)
	// mProductPlate.setPlateBarCode(""); // vb 1/31 to avoid null pointer exception
	// AnalyticalPlateBatchViewPanel plateBatchViewPanel = (AnalyticalPlateBatchViewPanel)
	// plateViews.get(mProductPlate.getPlateBarCode());
	// plateRackViewTab.addTab(mProductPlate.getPlateBarCode(), plateBatchViewPanel);
	// }
	// JPanel plateTabTableViewPanel = (JPanel) plateTablePaneViews.get(mProductPlate.getLotNo());
	// plateTableViewTab.addTab(mProductPlate.getLotNo(), plateTabTableViewPanel);
	// }
	// // to be decided
	// switchView((String) viewOptionsCombo.getSelectedItem());
	// }
	// }

	private JPanel createComboBoxPanel(JComboBox switcher) {
		FlowLayout flowLayout2 = new FlowLayout(FlowLayout.RIGHT);
		JPanel comboPanel = new JPanel(flowLayout2);
		comboPanel.add(switcher);
		return comboPanel;
	}

	// for plate viewer
	private void createCollapsiblePane() {
		viewBatch_Pane = new CollapsiblePane(ParallelNotebookPageGUI.PLATEVIEWER_PANE);
		viewBatch_Pane.setStyle(CollapsiblePane.TREE_STYLE);
		viewBatch_Pane.setBackground(CeNConstants.BACKGROUND_COLOR);
		viewBatch_Pane.setSteps(1);
		viewBatch_Pane.setStepDelay(0);
		viewBatch_Pane.getContentPane().setLayout(new BorderLayout());
	}// end method

	public CollapsiblePane getPlateViewer() {
		return viewBatch_Pane;
	}

	/**
	 * @return the plateRackViewTab
	 */
	public JTabbedPane getPlateRackViewTab() {
		return plateRackViewTab;
	}

	/**
	 * @return the plateTableViewTab
	 */
	// public JTabbedPane getPlateTableViewTab() {
	// return plateTableViewTab;
	// }
	public void newProductPlatesCreated(ProductBatchPlateCreatedEvent event) {
		long startTime = System.currentTimeMillis();
		List plates = event.getPlates();
		addPlatesToTabs(plates);
		//this.createNonPlatedBatchesViewTab();
		// add newly created plates to list with existing plates for a Reaction
		// Step
		// ((ReactionStepModel) pageModel.getReactionSteps().get(event.getStepIndex())).addProductPlates(plates);
		// update plate table view
		long endTime = System.currentTimeMillis();
		if (log.isInfoEnabled()) {
			log.info("newProductPlatesCreated execution time: " + (endTime - startTime) + " ms");
		}
		updateProducts();
	}

	private void addProductsToTabs(NotebookPageModel pageModel) {
		List reactionSteps = pageModel.getReactionSteps();
		if (reactionSteps == null || reactionSteps.size() < 1) {
			// log no products error
			return;
		}
		if (reactionSteps.size() == 1) {
			ReactionStepModel reactionStep = (ReactionStepModel) reactionSteps.get(0);
			this.createProductTab(reactionStep, 1, true);
		} else {
			for (int i = 1; i < reactionSteps.size(); i++) {
				boolean isLastStep = i + 1 == reactionSteps.size();
				ReactionStepModel reactionStep = (ReactionStepModel) reactionSteps.get(i);
				this.createProductTab(reactionStep, i, isLastStep);
			}
		}
	}

	private void createProductTab(ReactionStepModel reactionStep, int stepNumber, boolean isLastStep) {
		List batches = reactionStep.getAllActualProductBatchModelsInThisStep();
		Collections.sort(batches, new NbkBatchNumberComparator());
		AnalyticalDetailTableView plateTableViewTable = new AnalyticalDetailTableView(this.pageModel, batches,
				this.sampleRefContainer);
		plateTableViewTable.reload();
		this.tableList.add(plateTableViewTable);
		// If this is the last step, save the tableView for adding compounds
		if (isLastStep) {
			this.lastStepProductTableView = plateTableViewTable;
			parallelProductTablePopupMenuManagerForProductTable.addMouseListener(lastStepProductTableView, lastStep);
		}
		JScrollPane scrollTableViewPane = new JScrollPane(plateTableViewTable);
		AnalyticalDetailTableViewToolBar productTableViewToolBar = new AnalyticalDetailTableViewToolBar(plateTableViewTable);
		JPanel productTableViewPanel = new JPanel();
		productTableViewPanel.setLayout(new BorderLayout());
		productTableViewPanel.setBackground(Color.LIGHT_GRAY);
		productTableViewPanel.add(productTableViewToolBar, BorderLayout.NORTH);
		productTableViewPanel.add(scrollTableViewPane, BorderLayout.CENTER);
		if (isLastStep)
			productViews.put("Product", productTableViewPanel);
		else
			productViews.put("P" + stepNumber, productTableViewPanel);
	}

	private void addPlatesToTabs(List plates) {
		for (int i = 0; i < plates.size(); i++) {

			Object plateObj = plates.get(i);
			ProductPlate productPlate = (ProductPlate) plates.get(i);
			if (!(plateObj instanceof PseudoProductPlate)) {
				// Do table view part
				List batches = productPlate.getListOfProductBatches();
				AnalyticalDetailTableView plateTableViewTable = new AnalyticalDetailTableView(this.pageModel, batches,
						this.sampleRefContainer);
				plateTableViewTable.reload();
				this.tableList.add(plateTableViewTable);
				JScrollPane scrollTableViewPane = new JScrollPane(plateTableViewTable);
				// plateTableViewTable.setProductBatchDetailsContainerListener(mBatchSelectionListener);
				this.batchSelectionListeners = new BatchSelectionListener[1];
				nonPlatedTableView = plateTableViewTable;
				AnalyticalDetailTableViewToolBar productTableViewToolBar = new AnalyticalDetailTableViewToolBar(plateTableViewTable);
				JPanel plateTabTableViewPanel = new JPanel();
				plateTabTableViewPanel.setLayout(new BorderLayout());
				plateTabTableViewPanel.setBackground(Color.LIGHT_GRAY);
				plateTabTableViewPanel.add(productTableViewToolBar, BorderLayout.NORTH);
				plateTabTableViewPanel.add(scrollTableViewPane, BorderLayout.CENTER);
				productViews.put(productPlate.getLotNo(), plateTabTableViewPanel);
				// Do plate view part
				AnalyticalBatchEditPanel batchEditPanel = new AnalyticalBatchEditPanel(this.pageModel);
				this.batchSelectionListeners[0] = batchEditPanel;
				StaticPlateRenderer plateView = (StaticPlateRenderer) mCeNProductPlateBuilder.buildCeNproductPlateViewer(
						productPlate, this.batchSelectionListeners);
				AnalyticalPlateBatchViewPanel plateBatchViewPanel = new AnalyticalPlateBatchViewPanel(productPlate, plateView,
						batchEditPanel);
				this.plateViews.put(productPlate.getLotNo(), plateBatchViewPanel);
			}
		}
	}

/*
	private void createNonPlatedBatchesViewTab() {
		this.nonPlatedBatches.clear();
		this.nonPlatedBatches.addAll(pageModel.getNonPlatedBatches());
		PseudoProductPlate pseudoPlate = pageModel.getGuiPseudoProductPlate();
		productViews.remove(pseudoPlate.getLotNo());
		List batches = pseudoPlate.getListOfProductBatches();
		Collections.sort(batches, new NbkBatchNumberComparator());
		AnalyticalDetailTableView plateTableViewTable = new AnalyticalDetailTableView(this.pageModel, batches,
				this.sampleRefContainer);
		// plateTableViewTable.setAnalyticalDataModel(this.analyticalUtility);
		plateTableViewTable.reload();
		this.tableList.add(plateTableViewTable);
		// plateTableViewTable.setProductBatchDetailsContainerListener(mBatchSelectionListener);
		// ////////////BatchSelectionListener[] listeners = new BatchSelectionListener[2];
		// /////////////listeners[0] = mBatchSelectionListener;
		// listeners[1] = this;
		// /////plateTableViewTable.setProductBatchDetailsContainerListenerList(listeners);
		nonPlatedTableView = plateTableViewTable;
		parallelProductTablePopupMenuManagerForPlateTable.addMouseListener(nonPlatedTableView, lastStep);
		JScrollPane scrollTableViewPane = new JScrollPane(plateTableViewTable);
		AnalyticalDetailTableViewToolBar productTableViewToolBar = new AnalyticalDetailTableViewToolBar(plateTableViewTable);
		JPanel plateTabTableViewPanel = new JPanel();
		plateTabTableViewPanel.setLayout(new BorderLayout());
		plateTabTableViewPanel.setBackground(Color.LIGHT_GRAY);
		plateTabTableViewPanel.add(productTableViewToolBar, BorderLayout.NORTH);
		plateTabTableViewPanel.add(scrollTableViewPane, BorderLayout.CENTER);
		productViews.put(pseudoPlate.getLotNo(), plateTabTableViewPanel);
		// }
	}
	*/
	
	private void removePlatesFromTabs(List plates) {
		for (int i = 0; i < plates.size(); i++) {
			ProductPlate productPlate = (ProductPlate) plates.get(i);
			JPanel panel = (JPanel) productViews.get(productPlate.getLotNo());
			productTableTabbedPane.remove(panel);
			productViews.remove(productPlate.getLotNo());
			plateViews.remove(productPlate.getLotNo());
		}
	}

	public void prodcutPlatesRemoved(ProductBatchPlateCreatedEvent event) {
		removePlatesFromTabs(event.getPlates());
		switchView(selectedView);
	}

	public void newMonomerPlatesCreated(MonomerBatchPlateCreatedEvent event) {
	}

	public void monomerPlatesRemoved(MonomerBatchPlateCreatedEvent event) {
	}

	public void newRegisteredPlatesCreated(RegisteredPlateCreatedEvent event) {

	}

	public void registeredPlatesRemoved(RegisteredPlateCreatedEvent event) {

	}

	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			String viewer = (String) e.getItem();
			switchView(viewer);
		}
	}

	private void switchView(String comboText) {
		if (!isLoading) {
			// set the batch panel back to empty
			for (Iterator it = this.tableList.iterator(); it.hasNext();) {
				// PCeNTableView table = (PCeNTableView) it.next();
				AnalyticalDetailTableView table = (AnalyticalDetailTableView) it.next();
				table.setSelectedAreas(null); // vb 11/29
			}
			// if (batchSelectionListeners != null && batchSelectionListeners.length > 0) {
			// // There should only be one
			// this.batchSelectionListeners[0].batchSelectionChanged(new BatchSelectionEvent(this, null));
			// }
		}

		if (comboText.equals(TABLES_VIEW)) {
			if (plateRackViewTab != null)
				viewBatch_Pane.getContentPane().remove(plateRackViewTab);
			this.refreshTables();
			viewBatch_Pane.getContentPane().add(this.productTableTabbedPane, BorderLayout.CENTER);
		} else if (comboText.equals(PLATES_VIEW)) {
			if (plateRackViewTab != null || productTableTabbedPane != null) {
				viewBatch_Pane.getContentPane().remove(productTableTabbedPane);
			}
			this.refreshTables();
			viewBatch_Pane.getContentPane().add(refreshPlateView(), BorderLayout.CENTER);
		}

		// if (comboText.equals(RACK_VIEW)) {
		// if (plateRackViewTab != null || productTableTabbedPane != null) {
		// viewBatch_Pane.getContentPane().remove(productTableTabbedPane);
		// viewBatch_Pane.getContentPane().remove(plateTableViewTab);
		// }
		// this.refreshTables();
		// viewBatch_Pane.getContentPane().add(refreshPlateView(), BorderLayout.CENTER);
		// } else if (comboText.equals(PRODUCT_TABLE_VIEW)) {
		// // showTableViewInReactionStepTab();
		// if (plateRackViewTab != null)
		// viewBatch_Pane.getContentPane().remove(plateRackViewTab);
		// if (plateTableViewTab != null)
		// viewBatch_Pane.getContentPane().remove(plateTableViewTab);
		// this.refreshTables();
		// viewBatch_Pane.getContentPane().add(this.productTableTabbedPane, BorderLayout.CENTER);
		// } else if (comboText.equals(PLATE_TABLE_VIEW)) {
		// // add them to the collapsible pane
		// if (productTableTabbedPane != null)
		// viewBatch_Pane.getContentPane().remove(productTableTabbedPane);
		// if (plateRackViewTab != null)
		// viewBatch_Pane.getContentPane().remove(plateRackViewTab);
		// this.refreshTables();
		// viewBatch_Pane.getContentPane().add(this.refreshPlateTableView(), BorderLayout.CENTER);
		//			
		// } // end if
	}// end method

	// public void plateSelectionChanged(PlateSelectionChangedEvent event) {
	// //this.selectedPlates.clear();
	// //this.selectedPlates.addAll(event.getAllSelectedPlates());
	// //addPlatesToTabs(pageModel.getAllProductPlates());
	// //addNonPlatedBatchesToTabs();
	// this.selectedPlates = (ArrayList) event.getAllSelectedPlates();
	// final ProductPlate clickedPlate = event.getProductPlate();
	// boolean isSelected = clickedPlate.isSelect_analytical();
	//		
	// if (selectedView.equals(TABLES_VIEW)) {
	//			
	// } else if (selectedView) {
	//			
	// }
	//		
	// if (selectedView.equals(RACK_VIEW)) {
	// if (clickedPlate.getLotNo().equals(CeNConstants.PSEUDO_PLATE_LABEL))
	// return;
	// if (isSelected)
	// {
	// JPanel plateBatchViewPanel = (JPanel) plateViews.get(clickedPlate.getLotNo());
	// int tabCount = selectedPlates.indexOf(clickedPlate);
	// //No pseudoPlate view for the Plate Rack view.
	// if (((ProductPlate)selectedPlates.get(0)).getLotNo().equals(CeNConstants.PSEUDO_PLATE_LABEL))
	// tabCount = tabCount - 1;
	// plateRackViewTab.insertTab(clickedPlate.getLotNo(), null, plateBatchViewPanel, null, tabCount);
	// }
	// else
	// {
	// JPanel plateBatchViewPanel = (JPanel) plateViews.get(clickedPlate.getLotNo());
	// plateRackViewTab.remove(plateBatchViewPanel);
	// }
	// } else if (selectedView.equals(PLATE_TABLE_VIEW)) {
	// if (isSelected)
	// {
	// JPanel plateTabTableViewPanel = (JPanel) plateTablePaneViews.get(clickedPlate.getLotNo());
	// plateTableViewTab.insertTab(clickedPlate.getLotNo(), null, plateTabTableViewPanel, null,
	// selectedPlates.indexOf(clickedPlate));
	// }
	// else
	// {
	// JPanel plateTabTableViewPanel = (JPanel) plateTablePaneViews.get(clickedPlate.getLotNo());
	// plateTableViewTab.remove(plateTabTableViewPanel);
	// }
	// }
	// //updateSelectedPlatesProducts(event.getAllSelectedPlates());
	// }

	public void batchSelectionChanged() {
		// ArrayList products = lastStep.getProducts();
		// BatchesList lastBatchesList = (BatchesList) products.get(products.size() - 1);
		// ArrayList batchModels = lastBatchesList.getBatchModels();
		// ProductBatchModel lastProductBatchModel = (ProductBatchModel)batchModels.get(batchModels.size() - 1);
		// //////////////PCeNPlateTableRowSelectionChangeHandler utility = (PCeNPlateTableRowSelectionChangeHandler)
		// nonPlatedTableView.getConnector();
		// BatchSelectionEvent batchSelectionEvent = new BatchSelectionEvent(this, utility.getPlateWell(lastProductBatchModel));
		// mBatchSelectionListener.batchSelectionChanged(batchSelectionEvent);
	}

	/**
	 * Create the tool bar elements.
	 * 
	 * @return
	 */
	private JPanel createToolBarElements() {
		FlowLayout flowLayout2 = new FlowLayout(FlowLayout.LEFT);
		JPanel equivsPanel = new JPanel(flowLayout2);
		equivsPanel.add(reformaPlatesBtn);
		equivsPanel.add(applyAnalyticalBtn);
		equivsPanel.add(colorLegendBtn);
		equivsPanel.add(exportExcelBtn);
		equivsPanel.add(createViewOptionsPanel());
		return equivsPanel;
	}

	/**
	 * Create the view chooser.
	 * 
	 * @param switcher
	 * @return
	 */
	private JPanel createComboBoxPanel2(JComboBox switcher) {
		FlowLayout flowLayout2 = new FlowLayout(FlowLayout.RIGHT);
		JPanel comboPanel = new JPanel(flowLayout2);
		comboPanel.add(switcher);
		return comboPanel;
	}

	// vb 12/6 for updating mol strings in table
	public void compoundUpdated(CompoundCreationEvent event) {
		ProductBatchModel batchModel = (ProductBatchModel) event.getBatch();
		//		
		// if (lastStepProductTableView != null) {
		// PCeNProductTableModelConnector controller = (PCeNProductTableModelConnector)lastStepProductTableView.getConnector();
		// controller.updateProductBatchModel(batchModel);
		// }
		//
		// if (nonPlatedTableView != null) {
		// PCeNProductTableModelConnector controller1 = (PCeNProductTableModelConnector)nonPlatedTableView.getConnector();
		// controller1.updateProductBatchModel(batchModel);
		// }

	}

	public void batchSelectionChanged(BatchSelectionEvent event) {
		Object obj = event.getSubObject();
		ProductBatchModel batch = null;
		if (obj instanceof PlateWell) {
			PlateWell well = (PlateWell) obj;
			batch = (ProductBatchModel) well.getBatch();
		} else if (obj instanceof ProductBatchModel) {
			batch = (ProductBatchModel) obj;
		}
		// if (batch != null) {
		// if (batch.getBatchType().compareTo(userAddedBatchType) == 0)
		// this.setDeleteCompoundButtonEnabled(true);
		// else
		// this.setDeleteCompoundButtonEnabled(false);
		// }
	}

	public void compoundRemoved(CompoundCreationEvent event) {
		BatchModel model = event.getBatch();
		AnalyticalDetailTableModel tableModel = getTableModelForReactionStep(event.ReactionStepModel());
		addOrRemoveBatchInTableModel(model, tableModel, false);
		sampleRefContainer.fillAnalyticalSampleRefComboBox();
	}

	public void newCompoundCreated(CompoundCreationEvent event) {
		BatchModel model = event.getBatch();
		AnalyticalDetailTableModel tableModel = getTableModelForReactionStep(event.ReactionStepModel());
		addOrRemoveBatchInTableModel(model, tableModel, true);
		sampleRefContainer.fillAnalyticalSampleRefComboBox();
	}

	/**
	 * Add or remove batch model in Analytical table
	 * @param model batch model
	 * @param tableModel analytical table model 
	 * @param add true - add, false - remove
	 */
	private void addOrRemoveBatchInTableModel(BatchModel model, AnalyticalDetailTableModel tableModel, boolean add) {
		if (tableModel != null) {
			List batches = tableModel.getBatches();
			if (add) {
				batches.add(model);
			} else {
				batches.remove(model);
			}
			tableModel.updateCompounds(batches);
			tableModel.updateAnalyses();
			tableModel.fireTableDataChanged();
		}
	}
	
	/**
	 * Get table model from tabbed pane for given reaction step
	 * @param step reaction step
	 * @return table model from tabbed pane
	 */
	private AnalyticalDetailTableModel getTableModelForReactionStep(ReactionStepModel step) {
		List reactionSteps = pageModel.getReactionSteps();
		int index = reactionSteps.indexOf(step);
		JPanel panel = (JPanel) productTableTabbedPane.getComponent(index);
		for (Component component : panel.getComponents()) {
			if (component instanceof JScrollPane) {
				JScrollPane scrollPane = (JScrollPane) component;
				AnalyticalDetailTableView table = (AnalyticalDetailTableView) scrollPane.getViewport().getView();
				AnalyticalDetailTableModel tableModel = (AnalyticalDetailTableModel) table.getModel();
				return tableModel;
			}
		}
		return null;
	}
	
	private Component refreshPlateView() {
		this.plateRackViewTab.removeAll();
		int count = 0;

		for (Iterator iterator = plateViews.entrySet().iterator(); iterator.hasNext();) {
			Map.Entry entry = (Map.Entry) iterator.next();
			if (((String) entry.getKey()).equals(CeNConstants.PSEUDO_PLATE_LABEL)) {
				continue;
			}
			JPanel plateViewPanel = (JPanel) entry.getValue();
			plateRackViewTab.insertTab((String) entry.getKey(), null, plateViewPanel, null, count);
			count++;

		}

		return plateRackViewTab;
	}

	private void refreshTables() {
		for (Iterator it = tableList.iterator(); it.hasNext();) {
			Object obj = it.next();
			if (obj instanceof AnalyticalDetailTableView) {
				AnalyticalDetailTableView tableView = (AnalyticalDetailTableView) obj;
				tableView.updateAnalyses();
			}
		}
	}

	public void updateAnalyses() {
		for (Iterator it = tableList.iterator(); it.hasNext();) {
			AnalyticalDetailTableView tableView = (AnalyticalDetailTableView) it.next();
			tableView.updateAnalyses();
		}
//		System.out.println();
	}
}
