/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
package com.chemistry.enotebook.client.gui.page.analytical.parallel.table.summary;


import com.chemistry.enotebook.client.gui.page.batch.PCeNSummaryViewControllerUtility;
import com.chemistry.enotebook.client.gui.page.batch.events.PlateSelectionChangedEvent;
import com.chemistry.enotebook.client.gui.page.batch.events.PlateSelectionChangedListener;
import com.chemistry.enotebook.client.gui.tablepreferences.TableColumnInfo;
import com.chemistry.enotebook.client.gui.tablepreferences.TablePreferenceDelegate;
import com.chemistry.enotebook.domain.NotebookPageModel;
import com.chemistry.enotebook.domain.ProductPlate;
import com.chemistry.enotebook.domain.StoicModelInterface;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**  vb 7/19 change is here..............
 * 
 * 1.0
 * 
 */
public class PCeNAnalytical_SummaryViewControllerUtility extends PCeNSummaryViewControllerUtility {

	public PCeNAnalytical_SummaryViewControllerUtility(List productPlates, NotebookPageModel pageModel) {
		super(productPlates, pageModel);
		headerNames.add(PLATE_COMMENTS);
	}

	
	public void dispose() {
		super.dispose();
	}

	public String[] getHeaderNames() {
		return (String[])headerNames.toArray(new String[headerNames.size()]);
	}
	
	public Object getValue(int rowIndex, int colIndex) {
		if (productPlates == null)
			return " ";
		ProductPlate plate = (ProductPlate) productPlates.get(rowIndex);
		if (colIndex == 0) {//"Select to View"
			return new Boolean(plate.isSelect_analytical());
		} 
/*		if (colIndex == 7) {//"Plate Comments" 
			return plate.getPlateComments();
		}
*/		return super.getValue(rowIndex, colIndex);
	}

	public boolean isCellEditable(int rowIndex, int colIndex) {
		ProductPlate plate = (ProductPlate) productPlates.get(rowIndex);
		if (!plate.isEditable())
			return false;
		String columnName = (String) headerNames.get(colIndex);
/*		if (rowIndex == 7) //"Plate Comments"
		{
			ProductPlate plate = (ProductPlate) productPlates.get(rowIndex);
			return plate.isEditable();
		}
*/		return super.isCellEditable(columnName);
	}

	public void setValue(Object value, int rowIndex, int colIndex) {
/*		ProductPlate plate = (ProductPlate) productPlates.get(rowIndex);
		if (colIndex == 7) {//"Plate Comments" 
			plate.setPlateComments((String) value);
		}
		else 
*/		super.setValue(value, rowIndex, colIndex);
	}

	public void setSelectValue(int rowIndex) {
		ProductPlate plate = (ProductPlate) productPlates.get(rowIndex);
		plate.setSelect_analytical(!plate.isSelect_analytical());
		
		ArrayList selectedPlates = (ArrayList) getSelectedPlates();
		Collections.sort(selectedPlates);
		PlateSelectionChangedListener mPlateSelectionChangedListener  = null;
		PlateSelectionChangedEvent mPlateSelectionChangedEvent  = null;
		mPlateSelectionChangedEvent = new PlateSelectionChangedEvent(this, plate, selectedPlates);
		
		for (Iterator it = this.plateSelectionChangedListeners.iterator(); it.hasNext();) {
			mPlateSelectionChangedListener = (PlateSelectionChangedListener) it.next();

			if (mPlateSelectionChangedListener != null) {
				mPlateSelectionChangedListener.plateSelectionChanged(mPlateSelectionChangedEvent);
			}
		}
	}
		
	private List getSelectedPlates() {
		ArrayList selectedPlates = new ArrayList();
		for (int i = 0; i < productPlates.size(); i++) {
			ProductPlate plate = (ProductPlate) productPlates.get(i);
			if (plate.isSelect_analytical()) {
				selectedPlates.add(plate);
			}
		}
		return selectedPlates;

	}


	public TableColumnInfo getColumnInfoFromModelIndex(int modelIndex) {
		// TODO Auto-generated method stub
		return null;
	}


	public TablePreferenceDelegate getTablePreferenceDelegate() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public StoicModelInterface getProductBatchModel(int selectedRowIndex)
	{
		return null;
	}

}
