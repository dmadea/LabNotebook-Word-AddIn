/****************************************************************************
 * Copyright (C) 2009-2015 EPAM Systems
 * 
 * This file is part of Indigo ELN.
 * 
 * This file may be distributed and/or modified under the terms of the
 * GNU General Public License version 3 as published by the Free Software
 * Foundation and appearing in the file LICENSE.GPL included in the
 * packaging of this file.
 * 
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ***************************************************************************/
package com.chemistry.enotebook.client.gui.page.analytical.parallel.table.summary;


import com.chemistry.enotebook.client.gui.page.table.PCeNTableModel;
import com.chemistry.enotebook.client.gui.page.table.PCeNTableModelConnector;
import com.chemistry.enotebook.client.gui.page.table.PCeNTableView;

import javax.swing.*;
import javax.swing.table.TableCellEditor;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * 
 * 
 *
 */
public class PCeNAnalytical_SummaryTableView extends PCeNTableView implements FocusListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2382986785923784830L;
	private PCeNAnalytical_SummaryTableViewCellEditor mPcenAnalyticalSummaryTableViewCellEditor;//= new PcenPlateSummaryTableViewCellEditor();
	private PCeNAnalytical_SummaryTableViewCellRender mPcenAnalyticalSummaryTableViewCellRender = new PCeNAnalytical_SummaryTableViewCellRender();
	private JTextField textFieldPlateComments = new JTextField();
	private TableCellEditor plateCommentsCellEditor = new DefaultCellEditor(textFieldPlateComments);

	
	public PCeNAnalytical_SummaryTableView(PCeNTableModel model, int rowHeight, PCeNTableModelConnector connector) {
		super(model, rowHeight, connector, null);
		mPcenAnalyticalSummaryTableViewCellEditor = new PCeNAnalytical_SummaryTableViewCellEditor();
		setTableViewCellRenderers();
		textFieldPlateComments.addFocusListener(this);
		this.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent evt) {
				if (evt.getClickCount() == 1) {
					checkboxclicked(evt);
				}
			} // end mouseClicked

		});

	}

	private void checkboxclicked(MouseEvent evt) {
		String columnName = getColumnName(this.getSelectedColumn());
		if (columnName.equalsIgnoreCase("View")) {
			PCeNAnalytical_SummaryViewControllerUtility controller = (PCeNAnalytical_SummaryViewControllerUtility) connector;
			controller.setSelectValue(this.getSelectedRow());
			this.repaint();
		}

	}

//	protected void setTableViewCellRenderers() {
//		//setDefaultRenderer(java.lang.Number.class, new FractionCellRenderer(10, 6, SwingConstants.RIGHT));
//		//ParallelCeNTableViewCellRenderer cellRenderer = new ParallelCeNTableViewCellRenderer();
//		PCeNTableViewHeaderRenderer headerRenderer = new PCeNTableViewHeaderRenderer();
//		//ParallelCeNTableViewCellEditor cellEditor = new ParallelCeNTableViewCellEditor();
//		int colCount = getColumnCount();
//		for (int i = 0; i < colCount; i++) {
//			TableColumn col = getColumn(getColumnName(i));
//			String name = getColumnName(i);
//			if (name.equalsIgnoreCase("Plate Comments")) 
//				col.setCellEditor(plateCommentsCellEditor);
//			else
//				col.setCellEditor(mPcenAnalyticalSummaryTableViewCellEditor);
//			col.setCellRenderer(mPcenAnalyticalSummaryTableViewCellRender);
//			col.setHeaderRenderer(headerRenderer);
//		}// end for
//	}

	public void focusGained(FocusEvent arg0) {
		textFieldPlateComments.selectAll();
	}

	public void focusLost(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
